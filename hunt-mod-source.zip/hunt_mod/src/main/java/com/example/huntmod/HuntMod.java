package com.example.huntmod;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.GameMode;

import java.util.*;

import static net.minecraft.server.command.CommandManager.argument;
import static net.minecraft.server.command.CommandManager.literal;

public class HuntMod implements ModInitializer {
    private static final Map<UUID, String> TEAMS = new HashMap<>();
    private static final Map<String, Integer> PROGRESS = new LinkedHashMap<>();
    private static final Map<String, BlockPos> GENERATORS = new LinkedHashMap<>();
    private static final List<BlockPos> GATES = new ArrayList<>();
    private static boolean running = false;
    private static final int REPAIR_STEPS = 10;

    @Override public void onInitialize() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> dispatcher.register(
            literal("hunt")
              .then(literal("help").executes(ctx -> {
                  tell(ctx.getSource(), "§6/hunt start §7— начать раунд (2–6 игроков)");
                  tell(ctx.getSource(), "§6/hunt generator add <имя> <x> <y> <z> §7— добавить генератор (до 5)");
                  tell(ctx.getSource(), "§6/hunt gate add <x> <y> <z> §7— указать блок ворот, который исчезнет при побеге");
                  tell(ctx.getSource(), "§6/hunt status §7— прогресс; §6/hunt reset §7— сброс раунда");
                  tell(ctx.getSource(), "§7Каждый генератор чинится 10 нажатиями ПКМ по его блоку.");
                  return 1;
              }))
              .then(literal("start").requires(s -> s.hasPermissionLevel(2)).executes(ctx -> start(ctx.getSource())))
              .then(literal("status").executes(ctx -> status(ctx.getSource())))
              .then(literal("reset").requires(s -> s.hasPermissionLevel(2)).executes(ctx -> { reset(); tell(ctx.getSource(), "§eРаунд сброшен."); return 1; }))
              .then(literal("generator").then(literal("add")
                  .then(argument("name", StringArgumentType.word())
                    .then(argument("x", IntegerArgumentType.integer()).then(argument("y", IntegerArgumentType.integer()).then(argument("z", IntegerArgumentType.integer()).executes(ctx -> {
                        if (GENERATORS.size() >= 5) { tell(ctx.getSource(), "§cУже добавлено 5 генераторов. Используй /hunt reset перед настройкой новой карты."); return 0; }
                        String name = StringArgumentType.getString(ctx, "name");
                        BlockPos pos = new BlockPos(IntegerArgumentType.getInteger(ctx,"x"), IntegerArgumentType.getInteger(ctx,"y"), IntegerArgumentType.getInteger(ctx,"z"));
                        GENERATORS.put(name, pos); PROGRESS.put(name, 0);
                        tell(ctx.getSource(), "§aГенератор " + name + " добавлен на " + pos.toShortString()); return 1;
                    })))))))
              .then(literal("gate").then(literal("add")
                  .then(argument("x", IntegerArgumentType.integer()).then(argument("y", IntegerArgumentType.integer()).then(argument("z", IntegerArgumentType.integer()).executes(ctx -> {
                      BlockPos pos = new BlockPos(IntegerArgumentType.getInteger(ctx,"x"), IntegerArgumentType.getInteger(ctx,"y"), IntegerArgumentType.getInteger(ctx,"z"));
                      GATES.add(pos); tell(ctx.getSource(), "§aБлок ворот добавлен: " + pos.toShortString() + ". После ремонта всех генераторов этот блок будет удалён."); return 1;
                  }))))))
        ));
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (!(player instanceof ServerPlayerEntity sp) || !(world instanceof ServerWorld sw) || !running) return ActionResult.PASS;
            BlockPos clicked = hit.getBlockPos();
            for (Map.Entry<String, BlockPos> e : GENERATORS.entrySet()) {
                if (e.getValue().equals(clicked) && PROGRESS.getOrDefault(e.getKey(), 0) < REPAIR_STEPS && "survivor".equals(TEAMS.get(sp.getUuid()))) {
                    int p = PROGRESS.get(e.getKey()) + 1; PROGRESS.put(e.getKey(), p);
                    sp.sendMessage(Text.literal("§eРемонт " + e.getKey() + ": " + p * 10 + "%"), true);
                    if (p >= REPAIR_STEPS) {
                        broadcast(sw.getServer(), "§aГенератор " + e.getKey() + " починен!");
                        if (PROGRESS.values().stream().filter(v -> v >= REPAIR_STEPS).count() >= 5) openGates(sw.getServer());
                    }
                    return ActionResult.SUCCESS;
                }
            }
            return ActionResult.PASS;
        });
    }

    private static int start(ServerCommandSource source) {
        MinecraftServer server = source.getServer();
        List<ServerPlayerEntity> players = new ArrayList<>(server.getPlayerManager().getPlayerList());
        if (players.size() < 2 || players.size() > 6) { tell(source, "§cДля раунда нужно от 2 до 6 игроков онлайн: 1 убийца и 1–5 выживших."); return 0; }
        if (GENERATORS.size() != 5) { tell(source, "§cСначала настрой ровно 5 генераторов через /hunt generator add <имя> <x> <y> <z>."); return 0; }
        Collections.shuffle(players); TEAMS.clear(); PROGRESS.replaceAll((k,v) -> 0); running = true;
        for (int i=0; i<players.size(); i++) {
            ServerPlayerEntity p = players.get(i);
            String team = i == 0 ? "killer" : "survivor"; TEAMS.put(p.getUuid(), team);
            p.sendMessage(Text.literal(i == 0 ? "§cТы УБИЙЦА! Не дай им сбежать." : "§aТы ВЫЖИВШИЙ! Почини 5 генераторов и найди ворота."), false);
        }
        broadcast(server, "§6Раунд начался! Убийца: 1; выживших: " + (players.size()-1) + ". Генераторы: 0/5."); return 1;
    }
    private static int status(ServerCommandSource source) {
        long done = PROGRESS.values().stream().filter(v -> v >= REPAIR_STEPS).count();
        tell(source, "§6Генераторы: " + done + "/5. Ворота: " + (done >= 5 ? "§aоткрыты" : "§cзакрыты") + ".");
        for (Map.Entry<String,Integer> e : PROGRESS.entrySet()) tell(source, "§e" + e.getKey() + ": " + Math.min(100, e.getValue()*10) + "%");
        return 1;
    }
    private static void openGates(MinecraftServer server) {
        for (ServerWorld world : server.getWorlds()) for (BlockPos pos : GATES) world.setBlockState(pos, Blocks.AIR.getDefaultState());
        broadcast(server, "§aВсе 5 генераторов починены! ВОРОТА ОТКРЫТЫ — выжившие могут сбежать!");
    }
    private static void reset() { running = false; TEAMS.clear(); PROGRESS.replaceAll((k,v) -> 0); }
    private static void broadcast(MinecraftServer server, String msg) { server.getPlayerManager().broadcast(Text.literal(msg), false); }
    private static void tell(ServerCommandSource source, String msg) { source.sendFeedback(() -> Text.literal(msg), false); }
}
